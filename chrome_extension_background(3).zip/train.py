from gensim.test.utils import common_texts
from gensim.models.doc2vec import Doc2Vec, TaggedDocument
import argparse
import os
import os.path as osp
from sklearn.feature_extraction.text import TfidfVectorizer
from functools import reduce 
from operator import add
import nltk
import string
import pickle

def preprocess_doc(doc):
    """
    Preprocesses a document by removing unnecessary content.

    Args:
    - doc (str): The input document.

    Returns:
    - str: Processed document.
    """
    doc = doc.strip()
    index = doc.find("{document}")
    doc = doc[index + 10 :].strip()[:-14].strip()
    return doc

def preprocess_sentence(sent):
    """
    Preprocesses a sentence by removing punctuation and extra whitespaces.

    Args:
    - sent (str): The input sentence.

    Returns:
    - str: Processed sentence.
    """
    for i in string.punctuation:
        sent = sent.replace(i, "")
    sent = sent.strip()
    return sent

def cut(doc):
    """
    Tokenizes a document into sentences.

    Args:
    - doc (str): The input document.

    Returns:
    - list: List of tokenized sentences.
    """
    paragraphs = nltk.sent_tokenize(doc)
    cuts = [preprocess_sentence(para) for para in paragraphs]
    return cuts

doc2vec_parameters = {
    "vector_size": 5, "window": 2, "min_count": 1, "workers": 4
}

tf_idf_parameters = {
    "max_features": 400,
}

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", default="doc2vec", help="doc2vec or tfidf", type=str)
    parser.add_argument("--save_path", default="./doc2vec.model", help="save path", type=str)
    args = parser.parse_args()
    
    model_name = args.model
    save_path = args.save_path
    
    if model_name == "doc2vec":
        model = Doc2Vec
    elif model_name == "tf-idf":
        model = TfidfVectorizer(**tf_idf_parameters)
    
    docs = []
    
    root = "./doc"
    
    for name in os.listdir(root):
        if not name.endswith(".tex"):
            continue
        pth = osp.join(root, name)

        with open(pth, encoding="utf-8") as f:
            doc = f.read()
            doc = preprocess_doc(doc)
            docs.append(doc)

    if model_name == "doc2vec":
        docs = reduce(add, [cut(doc) for doc in docs], [])
        docs = [TaggedDocument(words, [i]) for i, words in enumerate(docs)]

        model = model(documents=docs, **doc2vec_parameters)
        model.save(save_path)
    elif model_name == "tf-idf":
        docs = reduce(add, [nltk.sent_tokenize(doc) for doc in docs], [])

        model.fit(docs)
        with open('model.pkl', 'wb') as f:
            pickle.dump(model, f)