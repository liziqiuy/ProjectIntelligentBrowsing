import numpy as np
from typing import List, Dict, Literal
import requests
import time
import openai 
import config
import chat
import string
import nltk
from sentence_transformers import SentenceTransformer

bert = SentenceTransformer(config.bert_model_name)

openai.my_api_key = config.chatgpt_35_api_key

from sklearn.metrics.pairwise import pairwise_distances

current_text = None

def url_to_latex(url):
    api_key = "6f65f1bf3bd484ba0c769a181c22af25b7eb88b51ee9f076f1bed786f4d06ba4"
    app_id  = "universityofillinois_urbanachampaign_feff22_563197"
    headers = {
    'app_id': app_id,
    'app_key': api_key,
    'Content-type': 'application/json'
    }
    url = "https://api.mathpix.com/v3/pdf"
    data= {
        "url" : "https://cs229.stanford.edu/notes2020spring/cs229-notes1.pdf",
        "conversion_formats" : {"md" : True}
    }
    
    r = requests.post(url=url,headers=headers,json=data,timeout=30)
    pdf_id = eval(r.text)['pdf_id']
    print(pdf_id)
    
    time.sleep(30)
    
    url = f"https://api.mathpix.com/v3/pdf/{pdf_id}.mmd"
    
    
    headers = {
        'app_key': api_key, 
        'app_id': app_id, 
    }

    response = requests.get(url, headers=headers,)
    
    return response.text



def document_split(doc: str) -> List[str]:
    """
    Splits a document into a list of paragraphs.

    Args:
    - doc (str): The input document.

    Returns:
    - List[str]: List of paragraphs.
    """
    return doc.split("\n")

def preprocess_sentence(sent):
    """
    Preprocesses a sentence by removing punctuation and extra whitespaces.

    Args:
    - sent (str): The input sentence.

    Returns:
    - str: Processed sentence.
    """
    for i in string.punctuation:
        sent = sent.replace(i, "")
    sent = sent.strip()
    return sent


def paragraphs_split(paragraphs: str) -> List[str]:
    """
    Splits a string of paragraphs into a list of individual paragraphs.

    Args:
    - paragraphs (str): Input string containing paragraphs.

    Returns:
    - List[str]: List of individual paragraphs.
    """
    paragraphs = nltk.sent_tokenize(paragraphs)
    cuts = [preprocess_sentence(para) for para in paragraphs]
    return cuts


class Factory:
    
    
    @staticmethod
    def interactivity_bert(paragraphs: str, question: str) -> Dict:
        """
        Placeholder for the interactivity function using BERT.

        Args:
        - paragraphs (str): Input paragraphs.
        - question (str): User's question.

        Returns:
        - Dict: Result of the interactivity request.
        """
        
        from functools import reduce 
        from operator import add
        paragraphs = document_split( current_text )
        sentences =  reduce(add,[paragraphs_split(x) for x in paragraphs],[])
        sentences = sentences + [question] 
        embedding_tensor = bert.encode(sentences)
        question = embedding_tensor[-1].reshape(1,-1)
        embedding_tensor = embedding_tensor[:-1]
        
        distance = pairwise_distances(question,embedding_tensor)
        distance = distance.flatten()
        index = np.argsort(distance)[:5]
        result = np.array(sentences)[index]
        
        return "\n".join(result.tolist())

    
    
    
    @staticmethod
    def interactivity_chatgpt35(paragraphs: str, question: str) -> Dict:
        """
        Placeholder for the interactivity function using ChatGPT-3.5.

        Args:
        - paragraphs (str): Input paragraphs.
        - question (str): User's question.

        Returns:
        - Dict: Result of the interactivity request.
        """
        message = f"""
        According to the following article.
        ----------------
        {current_text[:4000]}
        ---------------
        Answer the following question (output the answer directly).
        {question}
        """
       
        return chat.get_message(message)
    
        
    
    @staticmethod
    def interactivity_chatgpt4(paragraphs: str, question: str) -> Dict:
        """
        Placeholder for the interactivity function using ChatGPT-4.0.

        Args:
        - paragraphs (str): Input paragraphs.
        - question (str): User's question.

        Returns:
        - Dict: Result of the interactivity request.
        """
        message = f"""
        According to the following article.
        ----------------
        {current_text}
        ---------------
        Answer the following question (output the answer directly).
        {question}
        """
        return chat.get_message(message)
    
    
    @staticmethod
    def interactivity_doc2vec(paragraphs: str, question: str) -> Dict:
        """
        Placeholder for the interactivity function using Doc2Vec.

        Args:
        - paragraphs (str): Input paragraphs.
        - question (str): User's question.

        Returns:
        - Dict: Result of the interactivity request.
        """
        pass
    
    
    
    @staticmethod
    def interactivity_tfidf(paragraphs: str, question: str) -> Dict:
        """
        Placeholder for the interactivity function using TF-IDF.

        Args:
        - paragraphs (str): Input paragraphs.
        - question (str): User's question.

        Returns:
        - Dict: Result of the interactivity request.
        """
        pass
    
    
import train
    
def interactivity(url: str,
                  question: str, 
                  method: Literal["bert", "chatgpt-3.5", "chatgpt-4.0", "doc2vec", "tf-idf"] = "chatgpt-3.5",new_url=True) -> Dict:
    """
    Handles interactivity requests based on the specified method.

    Args:
    - url (str): Target URL.
    - question (str): User's question.
    - method (Literal["bert", "chatgpt-3.5", "chatgpt-4.0", "doc2vec", "tf-idf"]): The method to use for interactivity.

    Returns:
    - Dict: Result of the interactivity request.
    """
    global current_text
    if new_url or current_text is None:
        current_text = url_to_latex(url)
        current_text = train.preprocess_doc(current_text)

    if method == "chatgpt-3.5":
        r = Factory.interactivity_chatgpt35(None,question)
    elif method == "chatgpt-4.0":
        r = Factory.interactivity_chatgpt4(None,question)
    elif method == "bert":
        r = Factory.interactivity_bert(None,question)
    elif method == "doc2vec":
        r = Factory.interactivity_doc2vec(None,question)
    elif method == "tf-idf":
        r = Factory.interactivity_tfidf(None,question)
    
    return {
        "answer" : r,
        "current_text" : current_text,
        "url" : url,
        "method" : method
    } 
    