from flask import Flask, request, json

app = Flask(import_name=__name__)

@app.route('/interactivity', methods=["POST"])
def interactivity_request() :
    """
    Handles interactivity requests.

    Expects a JSON payload with the following structure:
    {
        "url": "target_url",
        "method": "HTTP_method",
        "question": "user_question"
    }

    Args:
    - None
    """
    data = json.loads(request.data)
    url = data['url']
    method = data["method"]
    question = data["question"]
    # Perform actions based on the received data (e.g., make API requests, process the question, etc.)

if __name__ == "__main__":
    app.run(host='0.0.0.0', debug=True)


