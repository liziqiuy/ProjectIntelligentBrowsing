import numpy as np
from typing import List, Dict, Literal

def document_split(doc: str) -> List[str]:
    """
    Splits a document into a list of paragraphs.

    Args:
    - doc (str): The input document.

    Returns:
    - List[str]: List of paragraphs.
    """
    pass


def paragraphs_split(paragraphs: str) -> List[str]:
    """
    Splits a string of paragraphs into a list of individual paragraphs.

    Args:
    - paragraphs (str): Input string containing paragraphs.

    Returns:
    - List[str]: List of individual paragraphs.
    """
    pass


class Factory:
    
    @staticmethod
    def interactivity_bert(paragraphs: str, question: str) -> Dict:
        """
        Placeholder for the interactivity function using BERT.

        Args:
        - paragraphs (str): Input paragraphs.
        - question (str): User's question.

        Returns:
        - Dict: Result of the interactivity request.
        """
        pass
    
    @staticmethod
    def interactivity_chatgpt35(paragraphs: str, question: str) -> Dict:
        """
        Placeholder for the interactivity function using ChatGPT-3.5.

        Args:
        - paragraphs (str): Input paragraphs.
        - question (str): User's question.

        Returns:
        - Dict: Result of the interactivity request.
        """
        pass
    
    @staticmethod
    def interactivity_chatgpt4(paragraphs: str, question: str) -> Dict:
        """
        Placeholder for the interactivity function using ChatGPT-4.0.

        Args:
        - paragraphs (str): Input paragraphs.
        - question (str): User's question.

        Returns:
        - Dict: Result of the interactivity request.
        """
        pass
    
    @staticmethod
    def interactivity_doc2vec(paragraphs: str, question: str) -> Dict:
        """
        Placeholder for the interactivity function using Doc2Vec.

        Args:
        - paragraphs (str): Input paragraphs.
        - question (str): User's question.

        Returns:
        - Dict: Result of the interactivity request.
        """
        pass
    
    @staticmethod
    def interactivity_tfidf(paragraphs: str, question: str) -> Dict:
        """
        Placeholder for the interactivity function using TF-IDF.

        Args:
        - paragraphs (str): Input paragraphs.
        - question (str): User's question.

        Returns:
        - Dict: Result of the interactivity request.
        """
        pass

    
def interactivity(url: str,
                  question: str, 
                  method: Literal["bert", "chatgpt-3.5", "chatgpt-4.0", "doc2vec", "tf-idf"]) -> Dict:
    """
    Handles interactivity requests based on the specified method.

    Args:
    - url (str): Target URL.
    - question (str): User's question.
    - method (Literal["bert", "chatgpt-3.5", "chatgpt-4.0", "doc2vec", "tf-idf"]): The method to use for interactivity.

    Returns:
    - Dict: Result of the interactivity request.
    """
    pass
